﻿using Autofac;

namespace PME.Web.Bootstrap
{
    public class WebModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {

        }
    }
}

