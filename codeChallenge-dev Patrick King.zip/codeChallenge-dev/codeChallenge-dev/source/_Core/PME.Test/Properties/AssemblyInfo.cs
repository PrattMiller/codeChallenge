﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PME Test Library")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("PME Test Library")]
[assembly: Guid("BF322CF1-581E-448A-B4F7-1A2700AC436A")]
[assembly: AssemblyCulture("")]

