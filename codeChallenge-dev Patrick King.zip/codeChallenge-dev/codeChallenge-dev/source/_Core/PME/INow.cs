﻿using System;

namespace PME
{
    public interface INow
    {
        DateTime Now
        {
            get;
        }

    }
}

