﻿using System;

namespace PME
{
    public interface ILookup
    {

        Guid Id
        {
            get;
        }
    }
}

