﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PME Global Library")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("PME Global Library")]
[assembly: Guid("BA99839F-DE2D-4E54-A856-4E1DBED024D1")]
[assembly: AssemblyCulture("")]

[assembly: InternalsVisibleTo("PME.Test")]

[assembly: ObfuscateAssembly(false)]

