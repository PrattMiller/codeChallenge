﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PME Web Test Library")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("PME Web Test Library")]
[assembly: Guid("F75E7D50-6EF1-4697-820C-2C507BF05F23")]
[assembly: AssemblyCulture("")]

